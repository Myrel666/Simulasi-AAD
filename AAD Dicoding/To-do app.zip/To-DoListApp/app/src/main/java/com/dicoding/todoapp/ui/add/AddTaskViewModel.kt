package com.dicoding.todoapp.ui.add

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.todoapp.R
import com.dicoding.todoapp.data.Task
import com.dicoding.todoapp.data.TaskRepository
import com.dicoding.todoapp.utils.Event
import kotlinx.coroutines.launch

class AddTaskViewModel(private val taskRepository: TaskRepository) : ViewModel() {
    var title = ""
    var description = ""
    var dueDateMillis: Long = System.currentTimeMillis()
    private val _snackBarText = MutableLiveData<Event<Int>>()
    val snackBarText: LiveData<Event<Int>> = _snackBarText
    private val _saved = MutableLiveData<Event<Boolean>>()
    val saved: LiveData<Event<Boolean>> = _saved
    private var saving = false

    fun save() {
        if (title == "" || description == "") {
            _snackBarText.value = Event(R.string.empty_task_message)
        } else {
            val task = Task(
                title = title,
                description = description,
                dueDateMillis = dueDateMillis,
            )
            if (!saving) {
                viewModelScope.launch {
                    saving = true
                    taskRepository.insertTask(task)
                    saving = false
                    _saved.value = Event(true)
                }
            }
        }
    }

    fun resetState() {
        title = ""
        description = ""
        dueDateMillis = System.currentTimeMillis()
    }
}