package com.dicoding.todoapp.ui.detail

import androidx.lifecycle.*
import com.dicoding.todoapp.R
import com.dicoding.todoapp.data.Task
import com.dicoding.todoapp.data.TaskRepository
import com.dicoding.todoapp.utils.Event
import kotlinx.coroutines.launch

class DetailTaskViewModel(private val taskRepository: TaskRepository) : ViewModel() {

    private val _taskId = MutableLiveData<Int>()

    private val _task = _taskId.switchMap { id ->
        taskRepository.getTaskById(id)
    }
    val task: LiveData<Task> = _task

    private val _toastText = MutableLiveData<Event<Int>>()
    val toastText: LiveData<Event<Int>> = _toastText

    private val _deleted = MutableLiveData<Event<Boolean>>()
    val deleted: LiveData<Event<Boolean>> = _deleted

    fun setTaskId(taskId: Int?) {
        if (taskId == _taskId.value) {
            return
        }
        _taskId.value = taskId
    }

    fun deleteTask() {
        viewModelScope.launch {
            _task.value?.let {
                taskRepository.deleteTask(it)
                _toastText.value = Event(R.string.task_deleted)
                _deleted.value = Event(true)
            }
        }
    }
}